#ifndef __lib2_hpp
#define __lib2_hpp

namespace lib2 {

_declspec(dllexport)
void bar();

}   // namespace lib2

#endif
